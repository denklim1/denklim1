﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Частное_охранное_предприятие_Климкин_214в
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string log1 = textBox1.Text;
            string parol2 = textBox2.Text;
            if (textBox1.Text == "" || textBox2.Text == "")
            {

                MessageBox.Show("Неверный логин или пароль!", "Ошибка!");
            }
            else
            {
                this.Hide();
                Form3 form3 = new Form3();
                form3.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 Register = new Form2();
            Register.ShowDialog();
        }
    }
}
